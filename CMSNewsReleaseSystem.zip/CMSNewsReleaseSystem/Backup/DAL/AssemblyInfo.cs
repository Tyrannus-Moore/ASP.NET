using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("���ݷ��ʲ�-Maticsoft.Net.SystemFramework")]
[assembly: AssemblyDescription("Maticsoft.Net.SystemFrameworkʾ����ĿԴ��")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("����ƽ")]
[assembly: AssemblyProduct("http://www.maticsoft.com")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
